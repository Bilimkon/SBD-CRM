CREATE VIEW actionHistory_v AS
SELECT s.id         id,
       se.username  seller,
       c.firstname  customer,
       s.cost_paid  cost_paid,
       s.total_cost total_cost,
       s.sale       sale,
       s.credit     credit,
       s.card       card,
       s.cash       cash,
       s.comment    comment,
       s.date_cr    date,
       s.up_by      up_by,
       s.date_up    date_up
FROM sellaction s
       JOIN seller se
       JOIN customer c
WHERE s.cr_by = se.id
  AND c.id = s.customer_id
ORDER BY id;

