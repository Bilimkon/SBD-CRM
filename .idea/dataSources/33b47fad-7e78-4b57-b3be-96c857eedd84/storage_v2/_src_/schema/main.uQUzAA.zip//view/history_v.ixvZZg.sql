CREATE VIEW history_v AS
SELECT h.product_id                product_id,
       s.username                  username,
       c.username                  customer,
       h.product_barcode           barcode,
       h.product_name,
       t.name                      type_name,
       h.product_quantity * h.cost total_cost,
       h.cost                      cost,
       h.product_quantity          quantity,
       h.date_cr                   date,
       h.sell_action_id            sell_action_id
FROM history h
       JOIN seller s
       JOIN customer c
       JOIN type t
WHERE h.seller_id = s.id
  AND h.customer_id = c.id
  AND h.product_type = t.id
ORDER BY h.date_cr;

