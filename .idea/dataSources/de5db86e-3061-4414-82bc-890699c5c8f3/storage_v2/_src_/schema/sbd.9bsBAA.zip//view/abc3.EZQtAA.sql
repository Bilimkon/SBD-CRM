CREATE VIEW abc3 AS
  SELECT
    sum('total cost')                        AS `total_cost`,
    sum(`product_sold_rate`.`sold_quantity`) AS `total_quantity`,
    curdate()                                AS `Sana`
  FROM `sbd`.`product_sold_rate`;

