CREATE VIEW xisoblar AS
  SELECT
    `sbd`.`history`.`item_name`     AS `item_name`,
    `sbd`.`history`.`item_type`     AS `item_type`,
    `sbd`.`history`.`paid_date`     AS `paid_date`,
    `sbd`.`history`.`total_cost`    AS `total_cost`,
    `action2`.`creditAmount`        AS `creditAmount`,
    `action2`.`cardAmount`          AS `cardAmount`,
    `sbd`.`history`.`item_quantity` AS `item_quantity`,
    `sbd`.`sotuvchi`.`first_name`   AS `first_name`,
    `sbd`.`sotuvchi`.`last_name`    AS `last_name`
  FROM ((`sbd`.`history`
    JOIN `sbd`.`sotuvchi` ON ((`sbd`.`history`.`sotuvchi_id` = `sbd`.`sotuvchi`.`sotuvchi_id`))) JOIN
    `sbd`.`savdoaction` `action2` ON ((`sbd`.`history`.`savdo_action_id` = `action2`.`id`)));

