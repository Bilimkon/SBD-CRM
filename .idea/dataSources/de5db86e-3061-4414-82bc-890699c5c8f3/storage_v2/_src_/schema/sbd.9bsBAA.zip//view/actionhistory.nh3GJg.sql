CREATE VIEW actionhistory AS
  SELECT
    `s`.`id`                AS `id`,
    `h`.`tarix_id`          AS `tarix_id`,
    `h`.`sotuvchi_id`       AS `sotuvchi_id`,
    `h`.`paid_date`         AS `paid_date`,
    `h`.`total_cost`        AS `total_cost`,
    `s`.`creditDescription` AS `creditDescription`,
    `s`.`cardAmount`        AS `cardAmount`,
    `s`.`creditAmount`      AS `creditAmount`,
    sum(`h`.`total_cost`)   AS `Total_total`
  FROM (`sbd`.`history` `h`
    JOIN `sbd`.`savdoaction` `s` ON ((`h`.`savdo_action_id` = `s`.`id`)));

