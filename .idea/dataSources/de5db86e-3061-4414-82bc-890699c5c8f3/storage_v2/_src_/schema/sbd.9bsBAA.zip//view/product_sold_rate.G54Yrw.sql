CREATE VIEW product_sold_rate AS
  SELECT
    `sbd`.`history`.`tarix_id`           AS `tarix_id`,
    `sbd`.`history`.`sotuvchi_id`        AS `sotuvchi_id`,
    `sbd`.`history`.`item_id`            AS `item_id`,
    `sbd`.`history`.`item_name`          AS `item_name`,
    `sbd`.`history`.`item_barcode`       AS `item_barcode`,
    sum(`sbd`.`history`.`total_cost`)    AS `total cost`,
    sum(`sbd`.`history`.`item_quantity`) AS `sold_quantity`
  FROM `sbd`.`history`
  GROUP BY `sbd`.`history`.`item_id`;

