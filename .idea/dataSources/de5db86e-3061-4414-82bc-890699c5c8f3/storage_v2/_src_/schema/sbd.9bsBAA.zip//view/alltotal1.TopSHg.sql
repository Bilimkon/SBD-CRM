CREATE VIEW alltotal1 AS
  SELECT
    `abc3`.`total_cost`         AS `total_cost`,
    `abc3`.`total_quantity`     AS `total_quantity`,
    `abc1`.`Total_CreditAmount` AS `Total_CreditAmount`,
    `abc1`.`Total_cardAmount`   AS `Total_cardAmount`,
    `abc1`.`Sana`               AS `Sana`
  FROM (`sbd`.`abc3`
    JOIN `sbd`.`abc1` ON ((`abc1`.`Sana` = `abc3`.`Sana`)));

