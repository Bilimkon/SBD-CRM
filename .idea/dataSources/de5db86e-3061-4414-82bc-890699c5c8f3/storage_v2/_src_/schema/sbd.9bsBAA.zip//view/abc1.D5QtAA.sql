CREATE VIEW abc1 AS
  SELECT
    sum(`actionhistory`.`creditAmount`) AS `Total_CreditAmount`,
    sum(`actionhistory`.`cardAmount`)   AS `Total_cardAmount`,
    curdate()                           AS `Sana`
  FROM `sbd`.`actionhistory`;

