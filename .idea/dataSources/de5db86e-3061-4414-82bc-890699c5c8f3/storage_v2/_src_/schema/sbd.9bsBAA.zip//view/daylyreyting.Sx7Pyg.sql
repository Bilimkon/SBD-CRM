CREATE VIEW daylyreyting AS
  SELECT
    `actionhistory`.`tarix_id`               AS `tarix_id`,
    sum('total cost')                        AS `total_cost`,
    sum(`product_sold_rate`.`sold_quantity`) AS `total_quantity`,
    `actionhistory`.`paid_date`              AS `paid_date`
  FROM `sbd`.`actionhistory`
    JOIN (`sbd`.`product_sold_rate`
      JOIN `sbd`.`sotuvchi`)
  WHERE ((`actionhistory`.`sotuvchi_id` = `sbd`.`sotuvchi`.`sotuvchi_id`) AND (`actionhistory`.`creditAmount` > 0))
  GROUP BY `actionhistory`.`tarix_id`;

