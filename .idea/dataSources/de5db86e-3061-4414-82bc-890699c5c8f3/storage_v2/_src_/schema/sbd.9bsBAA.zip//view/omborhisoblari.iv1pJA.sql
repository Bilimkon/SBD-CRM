CREATE VIEW omborhisoblari AS
  SELECT
    `sbd`.`maxsulotlar`.`item_barcode`                                           AS `item_barcode`,
    `sbd`.`maxsulotlar`.`item_name`                                              AS `item_name`,
    `sbd`.`maxsulotlar`.`item_type`                                              AS `item_type`,
    `sbd`.`maxsulotlar`.`item_quantity`                                          AS `item_quantity`,
    `sbd`.`maxsulotlar`.`item_cost`                                              AS `item_cost`,
    `sbd`.`maxsulotlar`.`item_sale_cost`                                         AS `item_sale_cost`,
    (`sbd`.`maxsulotlar`.`item_quantity` * `sbd`.`maxsulotlar`.`item_cost`)      AS `item_total_cost`,
    (`sbd`.`maxsulotlar`.`item_quantity` * `sbd`.`maxsulotlar`.`item_sale_cost`) AS `item_total_sale_cost`
  FROM `sbd`.`maxsulotlar`
  GROUP BY `sbd`.`maxsulotlar`.`item_barcode`;

