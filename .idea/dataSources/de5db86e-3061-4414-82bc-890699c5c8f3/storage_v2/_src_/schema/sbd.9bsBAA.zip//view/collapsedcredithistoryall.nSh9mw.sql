CREATE VIEW collapsedcredithistoryall AS
  SELECT
    `actionhistory`.`id`                                                                                  AS `id`,
    `sbd`.`sotuvchi`.`sotuvchi_id`                                                                        AS `sotuvchi_id`,
    `sbd`.`sotuvchi`.`first_name`                                                                         AS `first_name`,
    `sbd`.`sotuvchi`.`last_name`                                                                          AS `last_name`,
    `actionhistory`.`cardAmount`                                                                          AS `cardAmount`,
    `actionhistory`.`creditAmount`                                                                        AS `credit`,
    `actionhistory`.`creditDescription`                                                                   AS `creditDescription`,
    sum(
        `actionhistory`.`total_cost`)                                                                     AS `total_cost`,
    ((sum(`actionhistory`.`total_cost`) - `actionhistory`.`cardAmount`) -
     `actionhistory`.`creditAmount`)                                                                      AS `paid_in_cash`
  FROM (`sbd`.`actionhistory`
    JOIN `sbd`.`sotuvchi`)
  WHERE (`actionhistory`.`sotuvchi_id` = `sbd`.`sotuvchi`.`sotuvchi_id`)
  GROUP BY `actionhistory`.`id`;

