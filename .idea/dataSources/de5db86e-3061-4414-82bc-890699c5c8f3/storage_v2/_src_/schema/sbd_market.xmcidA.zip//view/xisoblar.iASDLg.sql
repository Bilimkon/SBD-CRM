create definer = root@localhost view xisoblar as
select `sbd_market`.`history`.`item_name`     AS `item_name`,
       `sbd_market`.`history`.`item_type`     AS `item_type`,
       `sbd_market`.`history`.`paid_date`     AS `paid_date`,
       `sbd_market`.`history`.`total_cost`    AS `total_cost`,
       `action2`.`creditAmount`               AS `creditAmount`,
       `action2`.`cardAmount`                 AS `cardAmount`,
       `sbd_market`.`history`.`item_quantity` AS `item_quantity`,
       `sbd_market`.`sotuvchi`.`first_name`   AS `first_name`,
       `sbd_market`.`sotuvchi`.`last_name`    AS `last_name`
from ((`sbd_market`.`history` join `sbd_market`.`sotuvchi` on ((`sbd_market`.`history`.`sotuvchi_id` =
                                                                `sbd_market`.`sotuvchi`.`sotuvchi_id`)))
       join `sbd_market`.`savdoaction` `action2` on ((`sbd_market`.`history`.`savdo_action_id` = `action2`.`id`)));

