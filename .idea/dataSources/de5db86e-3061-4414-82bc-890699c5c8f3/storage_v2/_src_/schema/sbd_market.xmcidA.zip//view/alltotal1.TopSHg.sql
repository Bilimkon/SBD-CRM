create definer = root@localhost view alltotal1 as
select `abc3`.`total_cost`         AS `total_cost`,
       `abc3`.`total_quantity`     AS `total_quantity`,
       `abc1`.`Total_CreditAmount` AS `Total_CreditAmount`,
       `abc1`.`Total_cardAmount`   AS `Total_cardAmount`,
       `abc1`.`Sana`               AS `Sana`
from (`sbd_market`.`abc3`
       join `sbd_market`.`abc1` on ((`abc1`.`Sana` = `abc3`.`Sana`)));

