create definer = root@localhost view abc3 as
select sum('total cost')                        AS `total_cost`,
       sum(`product_sold_rate`.`sold_quantity`) AS `total_quantity`,
       curdate()                                AS `Sana`
from `sbd_market`.`product_sold_rate`;

