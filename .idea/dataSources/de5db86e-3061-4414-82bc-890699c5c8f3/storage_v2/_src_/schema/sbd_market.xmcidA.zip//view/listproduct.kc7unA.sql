create definer = root@localhost view listproduct as
select `sbd_market`.`maxsulotlar`.`id`           AS `id`,
       `sbd_market`.`maxsulotlar`.`item_barcode` AS `item_barcode`,
       `sbd_market`.`maxsulotlar`.`item_name`    AS `item_name`,
       `sbd_market`.`maxsulotlar`.`item_cost`    AS `item_cost`
from `sbd_market`.`maxsulotlar`
order by `sbd_market`.`maxsulotlar`.`id`;

