create definer = root@localhost view daylyreyting14 as
select sum('total cost')                        AS `total_cost`,
       sum(`product_sold_rate`.`sold_quantity`) AS `total_quantity`,
       curdate()                                AS `current_date`
from `sbd_market`.`product_sold_rate`;

