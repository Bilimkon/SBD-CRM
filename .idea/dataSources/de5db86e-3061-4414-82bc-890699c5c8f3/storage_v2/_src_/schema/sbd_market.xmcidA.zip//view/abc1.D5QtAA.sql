create definer = root@localhost view abc1 as
select sum(`actionhistory`.`creditAmount`) AS `Total_CreditAmount`,
       sum(`actionhistory`.`cardAmount`)   AS `Total_cardAmount`,
       curdate()                           AS `Sana`
from `sbd_market`.`actionhistory`;

