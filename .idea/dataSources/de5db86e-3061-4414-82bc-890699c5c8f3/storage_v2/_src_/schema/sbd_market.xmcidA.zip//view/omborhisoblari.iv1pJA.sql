create definer = root@localhost view omborhisoblari as
select `sbd_market`.`maxsulotlar`.`item_barcode`                                                  AS `item_barcode`,
       `sbd_market`.`maxsulotlar`.`item_name`                                                     AS `item_name`,
       `sbd_market`.`maxsulotlar`.`item_type`                                                     AS `item_type`,
       `sbd_market`.`maxsulotlar`.`item_quantity`                                                 AS `item_quantity`,
       `sbd_market`.`maxsulotlar`.`item_cost`                                                     AS `item_cost`,
       `sbd_market`.`maxsulotlar`.`item_sale_cost`                                                AS `item_sale_cost`,
       (`sbd_market`.`maxsulotlar`.`item_quantity` * `sbd_market`.`maxsulotlar`.`item_cost`)      AS `item_total_cost`,
       (`sbd_market`.`maxsulotlar`.`item_quantity` *
        `sbd_market`.`maxsulotlar`.`item_sale_cost`)                                              AS `item_total_sale_cost`
from `sbd_market`.`maxsulotlar`
group by `sbd_market`.`maxsulotlar`.`item_barcode`;

