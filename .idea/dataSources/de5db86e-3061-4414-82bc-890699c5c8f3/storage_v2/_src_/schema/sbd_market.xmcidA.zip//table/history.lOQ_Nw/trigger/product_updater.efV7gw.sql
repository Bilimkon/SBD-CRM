create definer = root@localhost trigger product_updater
  after INSERT
  on history
  for each row
BEGIN
       update maxsulotlar set item_quantity = item_quantity - new.item_quantity where item_barcode = new.item_barcode;
  END;

