create definer = root@localhost trigger timestampper
  before INSERT
  on savdoaction
  for each row
  SET new.savdoTime = DATE_FORMAT(NOW(), '%H:%s %m/%d/%Y');

