create definer = root@localhost view actionhistory as
select `s`.`id`                AS `id`,
       `h`.`tarix_id`          AS `tarix_id`,
       `h`.`sotuvchi_id`       AS `sotuvchi_id`,
       `h`.`paid_date`         AS `paid_date`,
       `h`.`total_cost`        AS `total_cost`,
       `s`.`creditDescription` AS `creditDescription`,
       `s`.`cardAmount`        AS `cardAmount`,
       `s`.`creditAmount`      AS `creditAmount`
from (`sbd_market`.`history` `h`
       join `sbd_market`.`savdoaction` `s` on ((`h`.`savdo_action_id` = `s`.`id`)));

