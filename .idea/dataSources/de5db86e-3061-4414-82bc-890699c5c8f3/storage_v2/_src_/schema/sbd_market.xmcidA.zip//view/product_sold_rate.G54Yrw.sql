create definer = root@localhost view product_sold_rate as
select `sbd_market`.`history`.`tarix_id`           AS `tarix_id`,
       `sbd_market`.`history`.`sotuvchi_id`        AS `sotuvchi_id`,
       `sbd_market`.`history`.`item_id`            AS `item_id`,
       `sbd_market`.`history`.`item_name`          AS `item_name`,
       `sbd_market`.`history`.`item_barcode`       AS `item_barcode`,
       sum(`sbd_market`.`history`.`total_cost`)    AS `total cost`,
       sum(`sbd_market`.`history`.`item_quantity`) AS `sold_quantity`
from `sbd_market`.`history`
group by `sbd_market`.`history`.`item_id`;

