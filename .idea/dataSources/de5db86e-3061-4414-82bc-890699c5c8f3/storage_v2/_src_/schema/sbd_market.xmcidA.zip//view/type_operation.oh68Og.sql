create definer = root@localhost view type_operation as
select `sbd_market`.`product_type`.`Id`          AS `id`,
       `sbd_market`.`product_type`.`Name`        AS `name`,
       `sbd_market`.`product_type`.`Measurament` AS `Measurament`,
       count(`sbd_market`.`maxsulotlar`.`id`)    AS `Total_products`
from (`sbd_market`.`product_type`
       join `sbd_market`.`maxsulotlar`)
where (`sbd_market`.`maxsulotlar`.`item_type` = `sbd_market`.`product_type`.`Name`)
group by `sbd_market`.`product_type`.`Id`;

