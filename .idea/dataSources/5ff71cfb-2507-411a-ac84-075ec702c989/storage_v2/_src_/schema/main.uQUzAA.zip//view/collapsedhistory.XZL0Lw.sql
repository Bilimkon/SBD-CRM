CREATE VIEW collapsedHistory as
  select
    id,
    cardAmount,
    creditAmount                 as 'credit',
    creditDescription,
    paid_date,
    sum(total_cost)              as 'total cost',
    sum(total_cost) - cardAmount - creditAmount as 'paid in cash'
  from actionHistory
  group by id;

