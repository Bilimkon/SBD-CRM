CREATE VIEW abc3 AS
  SELECT
    sum("total cost")  AS 'total_cost',
    sum(sold_quantity) AS 'total_quantity',
    current_date  as 'Sana'
  FROM product_sold_rate;

