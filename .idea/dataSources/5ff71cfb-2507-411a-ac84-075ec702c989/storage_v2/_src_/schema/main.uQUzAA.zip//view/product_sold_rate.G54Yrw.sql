CREATE VIEW product_sold_rate AS
  SELECT
    tarix_id,
    sotuvchi_id,
    item_id,
    item_name,
    item_barcode,
    sum(total_cost)    AS 'total cost',
    sum(item_quantity) AS 'sold_quantity'
  FROM history
  GROUP BY item_id;

