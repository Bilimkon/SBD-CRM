CREATE TRIGGER product_updater AFTER insert on history
  begin
  update maxsulotlar set item_quantity = item_quantity - new.item_quantity where item_barcode = new.item_barcode;
end;

