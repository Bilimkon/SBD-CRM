CREATE VIEW collapsedHistory as
  select
    id,
    sotuvchi.sotuvchi_id,
    sotuvchi.first_name,
    sotuvchi.last_name,
    cardAmount,
    creditAmount                 as 'credit',
    creditDescription,
    paid_date,
    sum(total_cost)              as 'total cost',
    sum(total_cost) - cardAmount - creditAmount as 'paid in cash'
  from actionHistory INNER JOIN sotuvchi where actionHistory.sotuvchi_id = sotuvchi.sotuvchi_id
  group by id;

