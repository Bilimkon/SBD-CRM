CREATE VIEW Xisoblar
  AS
SELECT  item_name,
        item_type,
        paid_date,
        total_cost,
        creditAmount,
        cardAmount,
        item_quantity,
        first_name,
        last_name
  FROM history
 INNER JOIN
    sotuvchi ON history.sotuvchi_id=sotuvchi.sotuvchi_id
 INNER JOIN savdoAction Action2 ON history.savdo_action_id = Action2.id;

