CREATE VIEW abc1 as
 SELECT

   sum(creditAmount) as 'Total_CreditAmount',
   sum(cardAmount)   as 'Total_cardAmount',
   current_date   as 'Sana'
   FROM actionHistory;

