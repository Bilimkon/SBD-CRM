CREATE VIEW OmborHisoblari AS
  SELECT
    item_barcode,
    item_name,
    item_type,
    item_quantity,
    item_cost,
    item_sale_cost,
    item_quantity * item_cost as 'item_total_cost',
    item_quantity * item_sale_cost as 'item_total_sale_cost'
FROM  maxsulotlar
  GROUP BY item_barcode;

