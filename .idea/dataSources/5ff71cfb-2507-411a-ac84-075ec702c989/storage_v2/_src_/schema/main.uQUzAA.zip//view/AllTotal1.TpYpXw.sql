CREATE VIEW AllTotal1 AS

SELECT
  total_cost,
  total_quantity,
  Total_CreditAmount,
  Total_cardAmount,
  abc1.Sana
  FROM abc3 JOIN abc1 on abc1.Sana = abc3.Sana;

